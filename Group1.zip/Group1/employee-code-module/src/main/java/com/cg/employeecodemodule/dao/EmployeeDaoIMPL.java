package com.cg.employeecodemodule.dao;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.employeecodemodule.exceptions.IDExistsException;
import com.cg.employeecodemodule.models.Employee;



@Repository
public class EmployeeDaoIMPL implements IEmployeeDao{
	
	@Autowired
	MongoTemplate mongotemplate;
	

	@Override
	public Employee createData(Employee employee) {
		employee.setEmployeeId(autogenarate());
		return mongotemplate.insert(employee);
	}

	private int autogenarate() {
	 Random random = new Random();
	 int n = 10000+random.nextInt(90000);
		return n;
	}

	@Override
	public Employee updateData(Employee employee,int  employeeId) {
		Employee detail=readData(employeeId);
		employee.setEmployeeId(employeeId);
		if(detail!=null){
			mongotemplate.save(employee);
		}else{
			throw new IDExistsException("Nothing to modify");
		}
		return employee;
		
	}

	@Override
	public List<Employee> readAll() {
		return mongotemplate.findAll(Employee.class);
	}

	@Override
	public Employee deleteData(int employeeId) {
		Employee detail=readData(employeeId);
		if(detail!=null){
			mongotemplate.remove(detail);
		}
		else {
			throw new IDExistsException("Employee does not exist");
		}
		return detail;
	}

	@Override
	public Employee readData(int employeeId) {
		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(employeeId));
		Employee details=mongotemplate.findOne(query, Employee.class);
		return details;
	}

}
